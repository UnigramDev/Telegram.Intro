#define LOGGING_ON 0
