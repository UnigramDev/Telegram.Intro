﻿using AngleTestLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace AngleTestSharp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private OpenGLESPage _renderer;

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void swapChainPanel_Loaded(object sender, RoutedEventArgs e)
        {
            _renderer = new OpenGLESPage(swapChainPanel);
            _renderer.Loaded();
        }

        private void FlipView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_renderer != null)
            {
                _renderer.CurrentPage = Flip.SelectedIndex;
            }
        }

        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            if (_renderer != null)
            {
                _renderer.CurrentPage = (int)e.NewValue;
            }
        }

        private void Slider_ValueChanged_1(object sender, RangeBaseValueChangedEventArgs e)
        {
            if (_renderer != null)
            {
                _renderer.CurrentScroll = (float)(e.NewValue / 100);
            }
        }
    }
}
