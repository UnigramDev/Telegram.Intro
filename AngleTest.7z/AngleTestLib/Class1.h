﻿#pragma once

#include "OpenGLES.h"
#include "SimpleRenderer.h"

using namespace Windows::UI::Xaml::Controls;

namespace AngleTestLib
{
	public ref class OpenGLESPage sealed
	{
	public:
		OpenGLESPage(SwapChainPanel^ swapChainPanel);
		virtual ~OpenGLESPage();

		void Loaded();

		property float CurrentScroll
		{
			float get() { return mCurrentScroll; }
			void set(float value)
			{
				mCurrentScroll = value;
			}
		}

		property int CurrentPage
		{
			int get() { return mCurrentPage; }
			void set(int value)
			{
				mCurrentPage = value;
			}
		}

	internal:
		OpenGLESPage(OpenGLES* openGLES, SwapChainPanel^ swapChainPanel);

	private:
		void OnVisibilityChanged(Windows::UI::Core::CoreWindow^ sender, Windows::UI::Core::VisibilityChangedEventArgs^ args);
		void CreateRenderSurface();
		void DestroyRenderSurface();
		void RecoverFromLostDevice();
		void StartRenderLoop();
		void StopRenderLoop();

		float mCurrentScale;

		float mCurrentScroll;
		int mCurrentPage;

		OpenGLES* mOpenGLES;
		OpenGLES mOpenGLESHolder;

		SwapChainPanel^ mSwapChainPanel;

		EGLSurface mRenderSurface;     // This surface is associated with a swapChainPanel on the page
		Concurrency::critical_section mRenderSurfaceCriticalSection;
		Windows::Foundation::IAsyncAction^ mRenderLoopWorker;
	};
}
