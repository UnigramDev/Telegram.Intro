#pragma once

GLuint setup_texture(LPTSTR fileName);
