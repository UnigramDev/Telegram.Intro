#ifdef __cplusplus
extern "C" {
#endif

	int irand(int from, int to);

	float frand(float from, float to);

	int signrand();

#ifdef __cplusplus
}
#endif